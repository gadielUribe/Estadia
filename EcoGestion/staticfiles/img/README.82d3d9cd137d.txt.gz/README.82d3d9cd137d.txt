Coloca aquí tu logo institucional como "upemor-logo.png".
Formato recomendado: PNG transparente o SVG.
La plantilla base lo referencia en: static/img/upemor-logo.png
